/**
 * Created by dosontung on 4/11/18.
 */

public class Grid
{
    int size = 0;
    int cellSize = 10;

    Grid(int size)
    {
        this.size = size;
    }
}
